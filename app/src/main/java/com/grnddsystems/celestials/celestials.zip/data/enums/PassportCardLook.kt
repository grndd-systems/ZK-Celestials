package com.grnddsystems.celestials.data.enums

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import com.grnddsystems.celestials.R
import com.grnddsystems.celestials.ui.theme.RarimeTheme

enum class PassportCardLook(val value: Int) {
    WHITE(0),
    BLACK(1),
    GREEN(2);

    companion object {
        fun fromInt(value: Int) = entries.first { it.value == value }
    }
}

@Composable
fun PassportCardLook.getBackgroundImage(modifier: Modifier = Modifier): Int {
    return when (this) {
        PassportCardLook.GREEN -> R.drawable.card_bg1
        PassportCardLook.BLACK -> R.drawable.card_bg2
        PassportCardLook.WHITE -> R.drawable.card_bg3
    }
}

@Composable
fun PassportCardLook.getBackgroundColor(): Color {
    return when (this) {
        PassportCardLook.GREEN -> RarimeTheme.colors.primaryMain
        PassportCardLook.BLACK -> RarimeTheme.colors.baseBlack
        PassportCardLook.WHITE -> RarimeTheme.colors.baseWhite
    }
}

@Composable
fun PassportCardLook.getForegroundColor(): Color {
    return when (this) {
        PassportCardLook.GREEN -> RarimeTheme.colors.baseBlack
        PassportCardLook.BLACK -> RarimeTheme.colors.baseBlack
        PassportCardLook.WHITE -> RarimeTheme.colors.baseBlack
    }
}

@Composable
fun PassportCardLook.getTitle(): String {
    return when (this) {
        PassportCardLook.GREEN -> stringResource(R.string.passport_look_green)
        PassportCardLook.BLACK -> stringResource(R.string.passport_look_black)
        PassportCardLook.WHITE -> stringResource(R.string.passport_look_white)
    }
}
