package com.grnddsystems.celestials.modules.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberBottomSheetScaffoldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState
import com.grnddsystems.celestials.R
import com.grnddsystems.celestials.data.tokens.PreviewerToken
import com.grnddsystems.celestials.manager.WalletAsset
import com.grnddsystems.celestials.modules.main.LocalMainViewModel
import com.grnddsystems.celestials.modules.wallet.components.WalletTransactionsList
import com.grnddsystems.celestials.modules.wallet.view_model.WalletViewModel
import com.grnddsystems.celestials.ui.base.ButtonIconSize
import com.grnddsystems.celestials.ui.components.CardContainer
import com.grnddsystems.celestials.ui.components.DropdownOption
import com.grnddsystems.celestials.ui.components.HorizontalDivider
import com.grnddsystems.celestials.ui.components.SecondaryIconButton
import com.grnddsystems.celestials.ui.components.TextDropdown
import com.grnddsystems.celestials.ui.theme.RarimeTheme
import com.grnddsystems.celestials.util.ErrorHandler
import com.grnddsystems.celestials.util.NumberUtil
import com.grnddsystems.celestials.util.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    navigate: (String) -> Unit,
    walletViewModel: WalletViewModel = hiltViewModel(),
) {
    val mainViewModel = LocalMainViewModel.current

    val userAssets by walletViewModel.walletAssets.collectAsState()
    val selectedUserAsset by walletViewModel.selectedWalletAsset.collectAsState()

    val scaffoldState = rememberBottomSheetScaffoldState()
    LaunchedEffect(scaffoldState.bottomSheetState.currentValue) {
        if (scaffoldState.bottomSheetState.currentValue == SheetValue.Expanded) {
            mainViewModel.setBottomBarVisibility(false)
        } else {
            mainViewModel.setBottomBarVisibility(true)
        }
    }

    LaunchedEffect(Unit) {
        walletViewModel.updateBalances()
    }

    WalletScreenContainer(
        selectedUserAsset = selectedUserAsset,
        userAssets = userAssets,
        updateSelectedWalletAsset = walletViewModel::updateSelectedWalletAsset,
        navigate = navigate,
        refreshWallet = {
            walletViewModel.updateBalances()
        }
    )

}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreenContainer(
    modifier: Modifier = Modifier,
    selectedUserAsset: WalletAsset,
    userAssets: List<WalletAsset>,
    updateSelectedWalletAsset: (WalletAsset) -> Unit,
    navigate: (String) -> Unit,
    refreshWallet: suspend () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isRefreshing by remember { mutableStateOf(false) }
    val state = rememberSwipeRefreshState(isRefreshing)

    val filteredUserAssets = userAssets.filter { it.showInAssets }
    SwipeRefresh(
        state = state,
        onRefresh = {
            isRefreshing = true
            coroutineScope.launch {
                refreshWallet()
                isRefreshing = false
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(RarimeTheme.colors.backgroundPrimary)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(40.dp),
                modifier = Modifier
                    .padding(vertical = 20.dp, horizontal = 12.dp)
            ) {
                Text(
                    text = stringResource(R.string.wallet_title),
                    style = RarimeTheme.typography.subtitle4,
                    color = RarimeTheme.colors.textPrimary,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.available_rmo),
                        style = RarimeTheme.typography.body4,
                        color = RarimeTheme.colors.textSecondary
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = NumberUtil.formatAmount(selectedUserAsset.humanBalance()),
                            style = RarimeTheme.typography.h4,
                            color = RarimeTheme.colors.textPrimary
                        )

                        // TODO: rollback at next releases
                        if (filteredUserAssets.size > 1) {
                            TextDropdown(
                                value = selectedUserAsset.getTokenSymbol().uppercase(),
                                options = filteredUserAssets.map {
                                    DropdownOption(
                                        label = it.getTokenSymbol(),
                                        value = it.getTokenSymbol()
                                    )
                                },
                                onChange = { symb ->
                                    run {
                                        val asset =
                                            filteredUserAssets.find { it.getTokenSymbol() == symb.uppercase() }
                                        ErrorHandler.logDebug("onChange: walletViewModel:", symb)
                                        ErrorHandler.logDebug(
                                            "onChange: asset:",
                                            asset?.getTokenSymbol() ?: "nope"
                                        )

                                        asset?.let { newAsset ->
                                            updateSelectedWalletAsset(
                                                newAsset
                                            )
                                        }
                                    }
                                }
                            )
                        } else {
                            Text(
                                text = selectedUserAsset.getTokenSymbol().uppercase(),
                                style = RarimeTheme.typography.overline2,
                                color = RarimeTheme.colors.textPrimary
                            )
                        }
                    }
                }

                Column(
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SecondaryIconButton(
                                size = ButtonIconSize.Large,
                                icon = R.drawable.ic_arrow_down,
                                onClick = { navigate(Screen.Main.Wallet.Receive.route) }
                            )
                            Text(
                                text = stringResource(R.string.receive_btn),
                                color = RarimeTheme.colors.textSecondary,
                                style = RarimeTheme.typography.buttonSmall
                            )
                        }
                        Spacer(modifier = Modifier.width(32.dp))
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SecondaryIconButton(
                                size = ButtonIconSize.Large,
                                icon = R.drawable.ic_arrow_up,
                                onClick = { navigate(Screen.Main.Wallet.Send.route) }
                            )
                            Text(
                                text = stringResource(R.string.send_btn),
                                color = RarimeTheme.colors.textSecondary,
                                style = RarimeTheme.typography.buttonSmall
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
//
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(vertical = 20.dp)
//        ) {
//            WalletTokensList(filteredUserAssets, selectedUserAsset)
//        }

            Column(
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.padding(horizontal = 12.dp)
            ) {

                CardContainer {

                    WalletTransactionsList(
                        modifier = Modifier.fillMaxSize(),
                        transactions = selectedUserAsset.transactions,
                        walletAsset = selectedUserAsset
                    )

                }

            }
        }
    }
}

@Preview
@Composable
private fun WalletScreenPreview() {

    var selectedAsset = remember {
        WalletAsset(
            "0xaddress",
            PreviewerToken("tokenAddress")
        )
    }
    WalletScreenContainer(
        selectedUserAsset = selectedAsset,
        userAssets = listOf(
            WalletAsset(
                "0xaddress",
                PreviewerToken("tokenAddress")
            ),
            WalletAsset(
                "0xaddress",
                PreviewerToken("tokenAddress", symbol = "USD"),
                showInAssets = false
            ),
        ),
        updateSelectedWalletAsset = { selectedAsset = it },
        navigate = {},
        refreshWallet = { delay(1500) },
    )
}
