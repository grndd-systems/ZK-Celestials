package com.grnddsystems.celestials.modules.votes.voteProcessScreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.grnddsystems.celestials.R
import com.grnddsystems.celestials.api.voting.models.MOCKED_POLL_ITEM
import com.grnddsystems.celestials.api.voting.models.PollCriteria
import com.grnddsystems.celestials.api.voting.models.PollCriteriaStatus
import com.grnddsystems.celestials.api.voting.models.UserInPoll
import com.grnddsystems.celestials.data.enums.AppColorScheme
import com.grnddsystems.celestials.data.enums.isDark
import com.grnddsystems.celestials.ui.base.BaseIconButton
import com.grnddsystems.celestials.ui.base.ButtonSize
import com.grnddsystems.celestials.ui.components.AppIcon
import com.grnddsystems.celestials.ui.components.HorizontalDivider
import com.grnddsystems.celestials.ui.components.PrimaryButton
import com.grnddsystems.celestials.ui.theme.RarimeTheme
import com.grnddsystems.celestials.util.DateUtil.getDateMessage
import com.grnddsystems.celestials.util.Screen
import kotlinx.coroutines.launch

private enum class VotingStatus {
    LOADING, ALREADY_VOTED, ALLOWED, NOT_STARTED, NO_PASSPORT, NO_IDENTITY
}

@Composable
fun VoteProcessInfoScreen(
    modifier: Modifier = Modifier,
    userInPoll: UserInPoll,
    onClose: () -> Unit,
    onClick: () -> Unit,
    navigate: (String) -> Unit,
    checkIsVoted: suspend () -> Boolean,
    colorMode: AppColorScheme
) {
    val isPassportVerified = remember {
        userInPoll.userVerificationStatus == PollCriteriaStatus.VERIFIED
    }

    val isEligible = remember {
        userInPoll.pollCriteriaList.none { !it.accomplished }
    }

    val context = LocalContext.current

    var voteState by remember {
        mutableStateOf(VotingStatus.LOADING)
    }

    val scope = rememberCoroutineScope()


    LaunchedEffect(Unit) {
        scope.launch {


            if (!userInPoll.poll.isStarted) {
                voteState = VotingStatus.NOT_STARTED
                return@launch
            }
            if (!isPassportVerified) {
                voteState = VotingStatus.NO_PASSPORT
                return@launch
            }
            if (!isEligible) {
                return@launch
            }
            val isVoted = checkIsVoted()
            voteState = if (isVoted) {
                VotingStatus.ALREADY_VOTED
            } else {
                VotingStatus.ALLOWED
            }
        }
    }

    Column(
        modifier = Modifier
            .then(modifier)
    ) {

        Box {
            BaseIconButton(
                modifier = Modifier
                    .padding(top = 20.dp, end = 20.dp)
                    .align(Alignment.TopEnd)
                    .zIndex(2f),
                onClick = onClose,
                icon = R.drawable.ic_close,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RarimeTheme.colors.inverted,
                    contentColor = RarimeTheme.colors.textPrimary
                ),
            )

            if (userInPoll.poll.imageUrl == null) {
                Image(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1284.0f / 696.0f),
                    painter = if (colorMode.isDark()) painterResource(R.drawable.bg_globe_dark) else painterResource(
                        R.drawable.bg_globe_light
                    ),
                    contentDescription = null
                )
            } else {
                AsyncImage(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1572.0f / 912.0f),
                    model = "https://ipfs.rarimo.com/ipfs/" + userInPoll.poll.imageUrl,
                    contentDescription = null,
                )
            }


        }


        Column(modifier = Modifier.padding(vertical = 20.dp, horizontal = 24.dp)) {
            Text(
                text = userInPoll.poll.title,
                color = RarimeTheme.colors.textPrimary,
                style = RarimeTheme.typography.h3
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppIcon(
                        id = R.drawable.ic_timer_line,
                        tint = RarimeTheme.colors.textSecondary
                    )
                    Text(
                        text = getDateMessage(poll = userInPoll.poll, context),
                        style = RarimeTheme.typography.subtitle7,
                        color = RarimeTheme.colors.textSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppIcon(
                        id = R.drawable.ic_group_line,
                        tint = RarimeTheme.colors.textSecondary
                    )
                    Text(
                        text = userInPoll.poll.proposalResults[0].sum().toString(),
                        style = RarimeTheme.typography.subtitle7,
                        color = RarimeTheme.colors.textSecondary
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = userInPoll.poll.description,
                style = RarimeTheme.typography.body4,
                color = RarimeTheme.colors.textSecondary
            )
            Spacer(modifier = Modifier.height(12.dp))
            if (!userInPoll.poll.isRankingBased) {
                Text(
                    text = userInPoll.poll.questionList.size.toString() + " questions",
                    style = RarimeTheme.typography.body4,
                    color = RarimeTheme.colors.textSecondary
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()

            Spacer(modifier = Modifier.height(24.dp))
            if (
                userInPoll.pollCriteriaList.isNotEmpty()
            ) {
                Text(
                    "Criteria",
                    style = RarimeTheme.typography.overline2,
                    color = RarimeTheme.colors.textSecondary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    userInPoll.pollCriteriaList.map {
                        Row {
                            AppIcon(
                                id = if (it.accomplished) R.drawable.ic_checkbox_circle_fill else R.drawable.ic_close_circle_fill,
                                tint = if (it.accomplished) RarimeTheme.colors.secondaryMain else RarimeTheme.colors.errorMain
                            )
                            Text(it.title)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            when (voteState) {

                VotingStatus.NO_PASSPORT -> {
                    PrimaryButton(
                        enabled = true,
                        modifier = Modifier.fillMaxWidth(),
                        text = stringResource(R.string.Celestial),
                        onClick = {
                            navigate(Screen.Main.Identity.route)
                        },
                        size = ButtonSize.Large
                    )
                }

                VotingStatus.NO_IDENTITY -> {

                }

                VotingStatus.LOADING ->
                    PrimaryButton(
                        enabled = false,
                        modifier = Modifier.fillMaxWidth(),
                        text = if (isEligible) "Loading..." else "Not eligible",
                        onClick = onClick,
                        size = ButtonSize.Large
                    )

                VotingStatus.ALREADY_VOTED ->
                    PrimaryButton(
                        enabled = false,
                        modifier = Modifier.fillMaxWidth(),
                        text = "Already voted",
                        onClick = onClick,
                        size = ButtonSize.Large
                    )

                VotingStatus.ALLOWED -> {
                    PrimaryButton(
                        enabled = isEligible,
                        modifier = Modifier.fillMaxWidth(),
                        text = if (isEligible) "Let’s start" else "Not eligible",
                        onClick = onClick,
                        size = ButtonSize.Large
                    )
                }

                VotingStatus.NOT_STARTED ->
                    PrimaryButton(
                        enabled = false,
                        modifier = Modifier.fillMaxWidth(),
                        text = "Voting has not started",
                        onClick = onClick,
                        size = ButtonSize.Large
                    )
            }
        }
    }
}

@Preview
@Composable
private fun VoteProcessInfoScreenPreview() {
    Surface {
        VoteProcessInfoScreen(
            userInPoll = UserInPoll(
                poll = MOCKED_POLL_ITEM,
                userVerificationStatus = PollCriteriaStatus.VERIFIED,
                pollCriteriaList = listOf(
                    PollCriteria(
                        title = "More than 18 years",
                        accomplished = true
                    ),
                    PollCriteria(
                        title = "Citizen of Georgia",
                        accomplished = true
                    )
                )
            ),
            onClose = {},
            onClick = {},
            navigate = {},
            checkIsVoted = { false },
            colorMode = AppColorScheme.DARK
        )
    }

}