package com.grnddsystems.celestials.modules.passportScan.models

import android.graphics.Bitmap

class Image {
    var bitmapImage: Bitmap? = null
    var base64Image: String? = null
}
